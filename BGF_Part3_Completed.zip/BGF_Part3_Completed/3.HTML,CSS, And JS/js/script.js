/* BGF Panelbeating JavaScript: search, gallery and form validation */
"use strict";

document.addEventListener("DOMContentLoaded", () => {
  // Keep the copyright year current on every page.
  document.querySelectorAll(".year").forEach(el => {
    el.textContent = new Date().getFullYear();
  });

  // Filter the services list by search term and selected category.
  const search = document.getElementById("service-search");
  const filter = document.getElementById("service-filter");
  if (search && filter) {
    const cards = [...document.querySelectorAll(".service-card")];
    const count = document.getElementById("service-count");
    const empty = document.getElementById("no-services");
    const updateServices = () => {
      const term = search.value.trim().toLowerCase();
      const category = filter.value;
      let visible = 0;
      cards.forEach(card => {
        const matchesText = card.dataset.name.includes(term);
        const matchesCategory = category === "all" || card.dataset.category === category;
        const show = matchesText && matchesCategory;
        card.classList.toggle("hidden", !show);
        if (show) visible++;
      });
      count.textContent = `${visible} service${visible === 1 ? "" : "s"} found.`;
      empty.classList.toggle("hidden", visible !== 0);
    };
    search.addEventListener("input", updateServices);
    filter.addEventListener("change", updateServices);
    updateServices();
  }

  // Accessible image lightbox.
  const lightbox = document.getElementById("lightbox");
  if (lightbox) {
    const preview = document.getElementById("lightbox-image");
    const close = document.getElementById("close-lightbox");
    document.querySelectorAll(".gallery-image").forEach(button => {
      button.addEventListener("click", () => {
        const image = button.querySelector("img");
        preview.src = button.dataset.full;
        preview.alt = image ? image.alt : "Enlarged gallery image";
        lightbox.classList.add("open");
        close.focus();
      });
    });
    const closeBox = () => {
      lightbox.classList.remove("open");
      preview.src = "";
    };
    close.addEventListener("click", closeBox);
    lightbox.addEventListener("click", event => {
      if (event.target === lightbox) closeBox();
    });
    document.addEventListener("keydown", event => {
      if (event.key === "Escape") closeBox();
    });
  }

  // Reusable client-side form validation.
  const validForm = form => {
    const invalid = [...form.querySelectorAll("input, select, textarea")]
      .find(field => !field.checkValidity());
    if (invalid) {
      invalid.focus();
      invalid.reportValidity();
      return false;
    }
    return true;
  };

  // Enquiry form: validate fields and show a relevant acknowledgement.
  const enquiryForm = document.getElementById("enquiry-form");
  if (enquiryForm) {
    enquiryForm.addEventListener("submit", event => {
      event.preventDefault();
      const error = document.getElementById("enquiry-error");
      const result = document.getElementById("enquiry-result");
      error.textContent = "";
      result.innerHTML = "";
      if (!validForm(enquiryForm)) {
        error.textContent = "Please correct the highlighted fields before submitting.";
        return;
      }
      const data = new FormData(enquiryForm);
      const service = data.get("type");
      const vehicle = data.get("vehicle") || "your vehicle";
      const message = document.createElement("p");
      message.textContent = `Thank you, ${data.get("name")}. Your ${service.toLowerCase()} enquiry for ${vehicle} has been checked successfully. BGF Panelbeating would need to assess the vehicle or confirm stock before providing a final price or availability. Please contact the business directly to continue.`;
      const box = document.createElement("div");
      box.className = "success";
      box.appendChild(message);
      result.appendChild(box);
      enquiryForm.reset();
    });
  }

  // Contact form: build a message for the visitor's default email application.
  const contactForm = document.getElementById("contact-form");
  if (contactForm) {
    contactForm.addEventListener("submit", event => {
      event.preventDefault();
      const error = document.getElementById("contact-error");
      const result = document.getElementById("contact-result");
      error.textContent = "";
      result.textContent = "";
      if (!validForm(contactForm)) {
        error.textContent = "Please correct the highlighted fields before preparing your email.";
        return;
      }
      // IMPORTANT: replace this placeholder with the verified business email address.
      const recipient = "REPLACE-WITH-VERIFIED-BUSINESS-EMAIL@example.com";
      const data = new FormData(contactForm);
      const subject = `BGF Panelbeating website: ${data.get("type")}`;
      const body = [
        `Name: ${data.get("name")}`,
        `Email: ${data.get("email")}`,
        `Phone: ${data.get("phone") || "Not supplied"}`,
        `Message type: ${data.get("type")}`,
        "",
        "Message:",
        data.get("message")
      ].join("\n");
      const mailto = `mailto:${recipient}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
      const note = document.createElement("p");
      note.className = "success";
      note.textContent = "Your email draft is ready. If your email application does not open, check that the business email address in js/script.js has been replaced with the correct address.";
      result.appendChild(note);
      window.location.href = mailto;
    });
  }
});
