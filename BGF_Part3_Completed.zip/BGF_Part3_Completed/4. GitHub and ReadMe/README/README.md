# BGF Panelbeating Website — Part 3

**Module:** WEDE5020 — Web Development (Introduction)  
**Student:** Maribe  
**Student number:** ST10453792  
**Project:** BGF Panelbeating

## Project overview
This is the Part 3 update of the BGF Panelbeating website. It builds on the supplied Part 2 HTML, CSS and image assets. The website contains five pages: Home, About Us, Services, Enquiry and Contact.

The project information supplied for the business states that it has operated since 8 June 2012 and is based in Mashamothane Zone 7, next to Sunrise Tavern, Burgersfort, Limpopo.

## Part 3 features implemented
- JavaScript service search and category filtering on `services.html`.
- JavaScript validation for required fields, email addresses, phone formats and message lengths.
- An enquiry acknowledgement that explains a final quote depends on an assessment or parts confirmation.
- A contact form that prepares an email using the visitor's default email application.
- Image gallery lightbox on `about.html`, including Escape-key and close-button support.
- Embedded Google Maps view for the supplied Burgersfort location.
- SEO title, description, keywords, canonical and robots metadata on every page.
- Descriptive image alternative text, semantic page structure and internal navigation.
- `robots.txt` and `sitemap.xml`.
- Responsive layout for desktop, tablet and mobile screens.

## Folder structure
```text
BGF_Part3_Completed/
├── index.html
├── about.html
├── services.html
├── enquiry.html
├── contact.html
├── robots.txt
├── sitemap.xml
├── README.md
├── css/
│   └── style.css
├── js/
│   └── script.js
└── images/
    ├── panel.image.jpg
    └── before and after panel.jpg
```

## Important configuration before publishing
1. In all five HTML pages, replace `https://YOUR-SITE-NAME.netlify.app` in the canonical link with the final published website URL.
2. Replace the same placeholder URL in `robots.txt` and `sitemap.xml`.
3. In `js/script.js`, replace `REPLACE-WITH-VERIFIED-BUSINESS-EMAIL@example.com` with the business's confirmed email address. Do not publish the placeholder.
4. Confirm the business address and map pin with the business owner. The project files supplied one location only; a second branch location was not added because no verified second address was provided.
5. Confirm that the supplied images are approved for public use before deployment.

## Testing checklist
- Open all five HTML pages and test every navigation link.
- On Services, search for a term such as `bumper` and test each category filter.
- On About Us, open each gallery image and close it using the close button and Escape key.
- On Enquiry, test empty fields, an invalid email, a short message and a valid enquiry.
- On Contact, test validation and confirm the email draft opens with the correct recipient after configuring the email address.
- Test the website at desktop, tablet and mobile widths using browser developer tools.
- Check that the map loads and that all images display.
- Validate the HTML and XML files before final submission.

## Deployment using Netlify
1. Sign in to Netlify and choose **Add new site** → **Import an existing project**.
2. Connect the GitHub repository containing this project.
3. Set the publish directory to the project root (leave the build command empty for this static HTML site).
4. Deploy the site.
5. Copy the published Netlify URL and replace the placeholder URL in the canonical links, `robots.txt` and `sitemap.xml`.
6. Commit and push those final URL updates, then redeploy.
7. Submit the live website URL and GitHub repository URL as required by the LMS.

## Suggested Git commands
```bash
git add .
git commit -m "Complete Part 3 JavaScript functionality and SEO"
git push origin main
```

## Changelog
### Part 3
- Added shared JavaScript for service searching and category filtering.
- Added an accessible image lightbox to the About page.
- Added client-side validation and feedback to the enquiry form.
- Added client-side validation and email-draft preparation to the contact form.
- Added SEO metadata, canonical URL placeholders and descriptive image alt text to all pages.
- Added `robots.txt` and `sitemap.xml`.
- Added an embedded map for the supplied Burgersfort workshop address.
- Improved responsive styling, keyboard access and reduced-motion support.
- Updated the README with setup, testing and deployment instructions.

## References
Google (n.d.) *Google Maps URLs*. Available at: https://developers.google.com/maps/documentation/urls (Accessed: 2 November 2026).

MDN Web Docs (n.d.) *Client-side form validation*. Available at: https://developer.mozilla.org/en-US/docs/Learn/Forms/Form_validation (Accessed: 2 November 2026).

MDN Web Docs (n.d.) *Document Object Model (DOM)*. Available at: https://developer.mozilla.org/en-US/docs/Web/API/Document_Object_Model (Accessed: 2 November 2026).

MDN Web Docs (n.d.) *The meta description element*. Available at: https://developer.mozilla.org/en-US/docs/Web/HTML/Element/meta/name (Accessed: 2 November 2026).

OpenAI (2026) *ChatGPT (GPT-6): assistance with JavaScript, HTML, CSS and project documentation*. Available at: https://chatgpt.com/ (Accessed: 2 November 2026). [AI assistance disclosure: AI-generated suggestions and code were reviewed and adapted for this student project. Include the required IIE AI disclosure annexure and screenshots separately.]

The Independent Institute of Education (2026) *Web Development (Introduction): WEDE5020 — Portfolio of Evidence, Part 3 instructions and marking rubric*. Internal learning material.
